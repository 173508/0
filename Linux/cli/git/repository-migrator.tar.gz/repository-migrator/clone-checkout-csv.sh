#!/bin/bash

# Check if CSV file is provided
if [ -z "$1" ]; then
  echo "Usage: $0 <csv_file>"
  exit 1
fi

echo
echo "##################################"
echo "## CSV File: $1"
echo "##"

# Read the CSV file line by line
while IFS=, read -r repo_url new_origin_url; do
  # Skip the header line
  if [ "$repo_url" == "repository_url" ]; then
    continue
  fi
  # Print the Details
  echo "----------------------------------------"
  echo -e "-- Processing repository -->\n--  $repo_url"
  echo -e "-- New origin URL -->\n--  $new_origin_url"
  echo

  # Begin the processing

  # Clone the repository
  git clone $repo_url
  # Extract the repository name from the URL
  repo_name=$(basename $repo_url .git)

  # Change into the repository directory
  cd $repo_name

  # Fetch all branches
  git fetch --all

  # Get a list of all branches except master and origin/HEAD
  branches=$(git branch -r | grep -v 'origin/master' | grep -v 'origin/HEAD' | sed 's/origin\///')

  # Checkout each branch one by one
  for branch in $branches; do
    git checkout $branch
  done

  # Checkout the master branch last
  git checkout master

  # Print all the branches
  echo
  echo " -- Branches"
  echo
  git branch -r

  # Rename master to main
  git branch -m master main

  # Change the remote origin to the new URL
  git remote set-url origin $new_origin_url

  # Check the number of branches
  branch_count=$(git branch | wc -l)

  # Push to the new origin
  if [ $branch_count -eq 1 ]; then
    git push -u origin main
  else
    git push --all origin -u
  fi

  # Move back to the parent directory
  cd ..
  rm -rf $repo_name

  # Completed the processing
  echo

done < $1

echo
echo "##################################"
