#!/bin/bash

ORG_NAME="myorganization" # GitHub Organlization
USERNAME="myusername"     # Valid GitHub User Name
PER_PAGE=100

# Verify gh cli is installed and authenticated
if ! command -v gh &> /dev/null; then
    echo "GitHub CLI not found. Please install it first."
    exit 1
fi

# Check if authenticated
if ! gh auth status &> /dev/null; then
    echo "Please authenticate with GitHub CLI first."
    exit 1
fi

# Function to list repositories with pagination
list_repos() {
    local cursor=""
    echo "Fetching repositories..."
    
    while true; do
        local after_arg=""
        if [ ! -z "$cursor" ]; then
            after_arg="\\\"$cursor\\\""
        else
            after_arg="null"
        fi

        query="query(\$org: String!) {
            organization(login: \$org) {
                repositories(first: ${PER_PAGE}, after: ${after_arg}, orderBy: {field: NAME, direction: ASC}) {
                    nodes {
                        name
                        visibility
                        description
                        createdAt
                        isPrivate
                    }
                    pageInfo {
                        hasNextPage
                        endCursor
                    }
                }
            }
        }"

        result=$(gh api graphql -f query="$query" -f org="$ORG_NAME")
        
        if [ $? -ne 0 ]; then
            echo "Error fetching repositories"
            exit 1
        fi

        # Check if result is valid
        if ! echo "$result" | jq -e '.data.organization.repositories.nodes' > /dev/null; then
            echo "Invalid response from GitHub API"
            exit 1
        fi

        # Format and display repository information
        echo "$result" | jq -r '.data.organization.repositories.nodes[] | "\(.name)\t\(.visibility)\t\(.createdAt)\t\(.description // "No description")"' | \
            column -t -s $'\t'
        
        # Check for more pages
        has_next_page=$(echo "$result" | jq -r '.data.organization.repositories.pageInfo.hasNextPage')
        [ "$has_next_page" = "false" ] && break
        
        cursor=$(echo "$result" | jq -r '.data.organization.repositories.pageInfo.endCursor')
    done
}

# Execute the function
list_repos
