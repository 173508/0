#!/bin/bash
##
# Migrate a Git repository from one remote to another
#
# Usage: ./repo-migrate.sh <repository_url> <new_origin_url>
#
# Example: 
# ./repo-migrate.sh 
#
#  This would print the help message
#
# Example: 
# ./repo-migrate.sh git@somehub.com:user/repo.git git@otherhub.com:user2/repo.git
# 
# This would migrate the repository from somehub to 
#  otherhub were user2 has access to both the repositories.
#

# Check if repository URL and new origin URL are provided
if [ -z "$1" ] || [ -z "$2" ]; then
  echo "Usage: $0 <repository_url> <new_origin_url>"
  exit 1
fi

# Clone the repository
git clone $1
# Extract the repository name from the URL
repo_name=$(basename $1 .git)

# Change into the repository directory
cd $repo_name

# Fetch all branches and tags
git fetch --all
git fetch --all --tags

# Get a list of all branches except master and origin/HEAD
branches=$(git branch -r | grep -v 'origin/master' | grep -v 'origin/HEAD' | sed 's/origin\///')

# Checkout each branch one by one
for branch in $branches; do
  git checkout $branch
done

# Get a list of all tags
tags=$(git tag)

# Checkout each tag one by one
for tag in $tags; do
  git checkout $tag
done



# Print all the branches
echo
echo " -- Branches - Remote"
echo
git branch -r

echo
echo " -- Branches - Local"
echo
git branch -r

echo
echo " -- Tags"
echo
git tag -l

echo

# Check if master branch exists and checkout if it does
if git show-ref --verify --quiet refs/heads/master; then
  # Checkout the master branch last
  git checkout master
  # Rename master to main
  git branch -m master main
else
  git checkout main
fi

# Change the remote origin to the new URL
git remote set-url origin $2

# Check the number of branches
branch_count=$(git branch | wc -l)

# Push to the new origin
if [ $branch_count -eq 1 ]; then
  git push -u origin main
else
  git push --all origin -u
fi

# Push all tags to the new origin
git push --tags origin

# Clean up afterwards
cd ..
rm -rf $repo_name
