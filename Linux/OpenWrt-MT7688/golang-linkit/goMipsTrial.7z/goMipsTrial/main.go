package main

/**
 * Example Program for Golang running on MT7688 MIPS platform
 */

import "fmt"

func main() {
	fmt.Println("Hari Aum !")
}
