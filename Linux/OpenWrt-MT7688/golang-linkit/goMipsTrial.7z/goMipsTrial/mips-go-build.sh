#!/usr/bin/env bash

# Example program for Golang compilation targeting MIPS on MT7688

# Build command
GOOS=linux GOARCH=mipsle GOMIPS=softfloat go build -trimpath -ldflags="-s -w" -o HariAum

# Compression Command
upx -9 HariAum

