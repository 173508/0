# avrboy

# What is this?

The avrboy is command line control software for ATtiny4_5_9_10_20_40Programmer_2.ino

original [ATtiny4_5_9_10_20_40Programmer.ino](https://drive.google.com/file/d/0B--e8M84W8o8UjJsSnI0bkVFT0U) is distributed by Keri DuPrey

The avrboy can be incorporated into Arduino IDE and used.

more info. https://make.kosakalab.com/make/electronic-work/arduino_tpi_en/
