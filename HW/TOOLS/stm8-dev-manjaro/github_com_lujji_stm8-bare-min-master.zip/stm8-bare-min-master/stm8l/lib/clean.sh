#!/bin/bash
rm -f *.map *.asm *.rel *.ihx *.o *.sym *.lk *.lst *.rst *.cdb
