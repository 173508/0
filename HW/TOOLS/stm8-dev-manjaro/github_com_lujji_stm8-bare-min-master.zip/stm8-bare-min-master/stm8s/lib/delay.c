#include "delay.h"

extern inline void delay_ms(uint32_t ms);
