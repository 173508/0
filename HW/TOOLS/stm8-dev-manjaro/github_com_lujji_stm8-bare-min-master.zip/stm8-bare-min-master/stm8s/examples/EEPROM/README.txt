This example writes a string "Test string" at the beginning of EEPROM and reads it back over UART.
