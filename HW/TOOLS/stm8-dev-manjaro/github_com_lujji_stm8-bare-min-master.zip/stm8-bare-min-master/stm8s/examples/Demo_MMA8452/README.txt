This example calculates inclination angle based on the readings from MMA8452 3-axis I2C accelerometer.
The output is shown on a "1602" HD44780 LCD. Pins used by the LCD are defined in `HD44780_config.h`.
Note that this demo initializes the LCD in single-line mode for 3V3 operation.
