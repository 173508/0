This example shows how to read and write option bytes. HSE stabilization time (OPT5) will be set to 128 HSE cycles.
