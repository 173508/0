This example shows how to mix C and assembly.
