This example demonstrates flash read/write operations.
