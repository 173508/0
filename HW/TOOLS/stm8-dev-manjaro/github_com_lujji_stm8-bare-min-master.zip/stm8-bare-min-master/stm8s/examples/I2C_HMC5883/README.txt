This example demonstrates I2C communication with HMC5883 magnetometer.

 --------------------
|                    |
|                PB4 |-> SCL
|                    |
|                PB5 |-> SDA
|                    |
|       <STM8>       |
|                    |
|                PD5 |-> TX
|                    |
|                PD6 |-> RX
|                    |
 --------------------
