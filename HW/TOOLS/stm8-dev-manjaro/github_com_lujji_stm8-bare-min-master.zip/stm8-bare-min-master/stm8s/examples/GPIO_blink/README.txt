This example toggles an LED on PD4 every 250 milliseconds.

 --------------------
|                    |
|                    |      270 Ohm
|                PD4 |------\/\/\-----
|                    |                |
|                    |              __|__
|       <STM8>       |              \   /  LED
|                    |              _\_/_
|                    |                |
|                    |               _|_
|                    |              [GND]
|                    |
 --------------------
