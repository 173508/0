This example shows how to use independent watchdog timer.
