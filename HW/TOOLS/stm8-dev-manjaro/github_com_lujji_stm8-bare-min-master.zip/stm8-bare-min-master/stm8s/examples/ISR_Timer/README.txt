This example demonstrates using TIM4 timer to generate a 100Hz waveform on pin PD3.
