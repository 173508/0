This example demonstrates interfacing with a generic "1602" HD44780 LCD.
Pins used by the LCD are defined in `HD44780_config.h`.
