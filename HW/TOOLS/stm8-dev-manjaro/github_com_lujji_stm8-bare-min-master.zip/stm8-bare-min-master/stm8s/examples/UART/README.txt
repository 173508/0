This example demonstrates UART functionality. UART1 is initialized at 9600 @ 8-N-1.
Baudrate is defined in stm8/uart.h

 --------------------
|                    |
|                    |
|                    |
|                    |
|                    |
|       <STM8>       |
|                    |
|                PD5 |-> TX
|                    |
|                PD6 |-> RX
|                    |
 --------------------
