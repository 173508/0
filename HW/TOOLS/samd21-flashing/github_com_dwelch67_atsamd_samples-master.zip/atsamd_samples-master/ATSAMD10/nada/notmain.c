
void dummy ( unsigned int );

int notmain ( void )
{
    unsigned int ra;

    for(ra=0;;ra++) dummy(ra);
}
