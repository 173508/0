if you want to use AIRKISS2.0 LAN discovery, should include airkiss.h and include libairkiss.a in makefile.

you can follow the steps below to achieve the function of LAN discovery.  
1.scan the two-dimension code in your wechat. 
2.running this smartconfig example.
3.wait device connect to AP and LAN discovery.

More detailed introduction refer to wechat.