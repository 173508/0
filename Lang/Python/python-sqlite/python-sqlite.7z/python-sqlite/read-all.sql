-- SQLite
SELECT * 
FROM customers;