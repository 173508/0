#!/usr/bin/env python3
# -*- code: utf-8 -*-

# Basic Example
# - Creating the Table Saving a database


import sqlite3  # It comes built In to Python No need anything Extra

# Create Connection to Database - Here its a file
conn = sqlite3.connect(__file__ + '.db')
# This is memory connection Database it would ge erased after program exit
conn_mem = sqlite3.connect(':memory:')

# We need to Create a Cursor to do things
c = conn.cursor()

# Create a Table
try:
    c.execute("""--sql
        CREATE TABLE customers (
            first_name TEXT,
            last_name TEXT,
            email TEXT
        )
            """)
# There are 5 datatypes supported in Sqlite
# NULL, INTEGER, REAL, TEXT, BLOB
# NULL - Boolean kind Exists or No Exists
# INTEGER - Whole numbers
# REAL - Decimals (Currency etc.)
# TEXT - Strings
# BLOB - Images, MP3file etc.
except sqlite3.OperationalError:
    print(" Table already Exists !!")

# Save the Data of all transactions
conn.commit()
# Close the Connection
conn_mem.close()
conn.close()
