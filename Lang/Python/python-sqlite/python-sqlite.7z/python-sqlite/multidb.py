import sqlite3
import os
# new Database
conn = sqlite3.connect('test.db')

c = conn.cursor()

# Main Table
c.execute("CREATE TABLE main (name TEXT,comment TEXT,date TEXT)")
conn.commit()
# Logging Table
c.execute("CREATE TABLE log (name TEXT,comment TEXT,date TEXT)")
conn.commit()

# Add data to the Main database
stuff = [
    ('Hari','I am here.','2023-03-23'),
    ('Gaurav', 'I need a friend', '2023-03-04'),
    ]
c.executemany("INSERT INTO main VALUES (?,?,?)",stuff)
conn.commit()

print(" Main Table ")
print("-------------")
# Display all records
c.execute("SELECT rowid, * from main")
items = c.fetchall()
for i in items:
    print(i)
    
# Copy one record to Log table
c.execute("INSERT INTO log SELECT * FROM main WHERE rowid = 1")
conn.commit()

print(" Log Table ")
print("-------------")
# Display all records
c.execute("SELECT rowid, * from log")
items = c.fetchall()
for i in items:
    print(i)

# Remove the Record from main table
c.execute("DELETE FROM main WHERE rowid = 1")
conn.commit()

print(" Main Table ")
print("-------------")
# Display all records
c.execute("SELECT rowid, * from main")
items = c.fetchall()
for i in items:
    print(i)

# Drop the Tables
c.execute("DROP TABLE main")
conn.commit()
c.execute("DROP Table log")
conn.commit()
# Close the Connection
conn.close()
# Clear the DB file
os.remove('test.db')