#!/usr/bin/env python3

# Example to Read data from the DB

import sqlite3
import os

os.remove(__file__ + '.db')
conn = sqlite3.connect(__file__ + '.db')

c = conn.cursor()

try:
    c.execute("""--sql
        CREATE TABLE customers (
            first_name TEXT,
            last_name TEXT,
            email TEXT
        )
            """)
except sqlite3.OperationalError:
    print(" Table already Exists !!")

many_customers = [
    ('Mohit', 'K', 'mohitk@gmail.com'),
    ('Jevan', 'P', 'jevanp@gmail.com'),
    ('Swati', 'BL', 'blswati@gmail.com'),
    ('Radhika', 'T', 'radhika@msn.com'),
]
try:
    c.executemany("""--sql
    INSERT INTO customers values (?,?,?)
              """, many_customers)
except sqlite3.OperationalError:
    print("Problem with Inserting data !")

conn.commit()

# Query the DB
c.execute("""--sql
    SELECT * FROM customers
          """)
# Print the All together Result
print(f"\nAll of them: \n {c.fetchall()}")

# Query the DB
c.execute("""--sql
    SELECT * FROM customers
          """)
# Only one record
print(f"\nOnly One : \n {c.fetchone()}")

# Query the DB
c.execute("""--sql
    SELECT * FROM customers
          """)
# Only first 3 records
print(f"\nFirst two: \n {c.fetchmany(2)}")

# Query the DB
c.execute("""--sql
    SELECT * FROM customers
          """)
print("\nFormatted Printing:\n")
items = c.fetchall()
# Print Fields
for i in items:
    print(f"{i[0]:10} {i[1]:4} | {i[2]}")

conn.close()
