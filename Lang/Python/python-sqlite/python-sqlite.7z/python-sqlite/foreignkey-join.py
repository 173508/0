import os
import os.path
import sqlite3
# Clean-up the file
if os.path.exists('test.db'): os.remove('test.db')
# Open the DB
conn = sqlite3.connect('test.db')
c = conn.cursor()
# Create a Table of Types
c.execute("""--sql
   CREATE TABLE IF NOT EXISTS types(
     id INTEGER UNIQUE PRIMARY KEY,
     type TEXT
   )""")
# NOTE We can't use the `rowid` for foreign key
#     Hence we need to use additional column to actually do it.
conn.commit()
# Add the Types - id field is auto generated as its the primary key.
stuff=[(None,'TODO'),(None,'PROJ'),(None,'REPEAT'),]
c.executemany("INSERT INTO types VALUES (?,?)",
              stuff)
conn.commit()
# Print the Types
print("  types Table  \n--------------------")
c.execute("SELECT * FROM types")
items = c.fetchall()
for i in items: print(i)
# Create table of Tasks
c.execute("""--sql
   CREATE TABLE IF NOT EXISTS tasks(
     id INTEGER UNIQUE PRIMARY KEY,
     type_id INTEGER,
     task TEXT,
     FOREIGN KEY (type_id) REFERENCES types(id)
   )""")
# We form the Relation here
conn.commit()
# Add Tasks
stuff=[
    (None,1,"Do Homework"),(None,3,"Wash Dishes"),
    (None,2,"Build a Plane"),(None,1,"Fetch the groceries list"),
]
c.executemany("INSERT INTO tasks VALUES (?,?,?)", stuff)
conn.commit()
# Display the Values with Inner Join
print(" tasks and types Inner Join\n-------------------------------")
c.execute("""--sql
   SELECT tasks.id, type, task FROM tasks
    LEFT JOIN types ON tasks.type_id = types.id
   """)
items = c.fetchall()
for i in items: print(i)
# Close
conn.close()
# Cleanup
os.remove('test.db')
