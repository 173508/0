# Python-Sqltie Tutorial

`2023-02-26` - Found some videos to Watch
  https://www.youtube.com/watch?v=byHcYRpMgI4

## Create the Environment

```batch
python -m venv .env
.env\Scripts\activate
```
## Some Details


