#!/usr/bin/env python3

# Example to Get the Index field or ID fields

import sqlite3
import os

if os.path.exists(__file__ + '.db'):
    os.remove(__file__ + '.db')
conn = sqlite3.connect(__file__ + '.db')
c = conn.cursor()

try:
    c.execute("""--sql
        CREATE TABLE customers (
            first_name TEXT,
            last_name TEXT,
            email TEXT
        )
            """)
    many_customers = [
        ('Mohit', 'K', 'mohitk@gmail.com'),
        ('Jevan', 'P', 'jevanp@gmail.com'),
        ('Swati', 'BL', 'blswati@gmail.com'),
        ('Radhika', 'T', 'radhika@msn.com'),
    ]
    c.executemany("""--sql
    INSERT INTO customers values (?,?,?)
              """, many_customers)
    conn.commit()
except sqlite3.OperationalError:
    print(" Table already Exists !!")

# Query with ID
c.execute("""--sql
    SELECT rowid, * FROM customers
          """)
# Print the Values
items = c.fetchall()

for i in items:
    print(i)

c.close()
