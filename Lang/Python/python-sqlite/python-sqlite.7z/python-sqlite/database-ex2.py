#!/usr/bin/env python3
# -*- code : utf-8 -*-

# Example of adding data into Tables

import sqlite3

conn = sqlite3.connect(__file__ + '.db')

c = conn.cursor()

try:
    c.execute("""--sql
        CREATE TABLE customers (
            first_name TEXT,
            last_name TEXT,
            email TEXT
        )
            """)
except sqlite3.OperationalError:
    print(" Table already Exists !!")

# Insert One Record
try:
    c.execute("""--sql 
        INSERT INTO customers VALUES ('Mohit', 'K', 'mohitk@gmail.com')
        """)
except sqlite3.OperationalError:
    print("Problem happened here - may be table does not exists !")

# Insert Multiple Records
many_customers = [
    ('Jevan', 'P', 'jevanp@gmail.com'),
    ('Swati', 'BL', 'blswati@gmail.com'),
    ('Radhika', 'T', 'radhika@msn.com'),
]
try:
    c.executemany("""--sql
    INSERT INTO customers values (?,?,?)
              """, many_customers)
except sqlite3.OperationalError:
    print("Problem with Inserting data !")

conn.commit()
conn.close()
